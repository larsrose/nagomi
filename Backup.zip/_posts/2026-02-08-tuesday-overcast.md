---
layout: post
title: Tuesday, Overcast
date: 2026-02-08
categories: [journal]
card_size: small
image: /assets/images/tuesday-overcast.jpg
---

Walked the canal path again. The herons are back. Finished reading Berger.
