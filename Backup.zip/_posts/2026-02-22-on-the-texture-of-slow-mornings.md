---
layout: post
title: On the Texture of Slow Mornings
date: 2026-02-22
categories: [journal]
card_size: large
image: /assets/images/slow-mornings.jpg
image_alt: A quiet cup of coffee in soft morning light
---

There’s something about the first cup of coffee, the light creeping through curtains, and the silence before the world begins.

<!--more-->

A meditation on unhurried beginnings, and the small rituals that make room for attention.
