---
layout: category
title: Research
category: research
permalink: /research/
description: Threads of inquiry — literature reviews, notes, and ongoing investigations.
---
