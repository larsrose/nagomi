---
layout: category
title: Essays
category: essays
permalink: /essays/
description: Long-form writing on technology, craft, attention, and the built environment.
---
