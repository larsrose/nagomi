---
layout: post
title: Attention Economies & Deep Work
date: 2026-02-05
categories: [research]
card_size: small
image: /assets/images/deep-work.jpg
---

A literature review on sustained focus in the age of infinite scroll.
