---
layout: post
title: The Architecture of Silence
date: 2026-02-10
categories: [essays]
card_size: wide
image: /assets/images/architecture-silence.jpg
image_alt: A quiet timber interior with natural light
---

How Japanese temples and Scandinavian cabins approach quietude through design.

<!--more-->

Notes from a year of visiting contemplative spaces.
