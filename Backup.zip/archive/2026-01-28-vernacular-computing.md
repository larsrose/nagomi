---
layout: post
title: Vernacular Computing
date: 2026-01-28
categories: [essays]
card_size: wide
image: /assets/images/vernacular-computing.jpg
---

What we lose when we optimize everything. An argument for software that feels handmade, local, and a little rough around the edges.
