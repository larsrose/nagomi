---
layout: post
title: Soil & Syntax
date: 2026-02-18
categories: [essays]
card_size: small
image: /assets/images/soil-syntax.jpg
image_alt: Hands working with soil and garden seedlings
---

What gardening taught me about writing code — patience, pruning, and the beauty of things that grow slowly.

<!--more-->

The garden is not a machine. Neither, in practice, is a codebase.
