---
layout: post
title: Distributed Systems in Mycorrhizal Networks
date: 2026-02-14
categories: [research]
card_size: medium
image: /assets/images/mycorrhizal.jpg
image_alt: Mycorrhizal networks beneath a forest floor
---

Exploring parallels between underground fungal communication and modern distributed computing architectures.

<!--more-->

These notes collect early observations and reading references.
