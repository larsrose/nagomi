# Marginalia for Jekyll

A responsive Jekyll port of the Marginalia blog: light green ground, irregular bento homepage, category-coloured cards, Libre Baskerville headings, IBM Plex Sans body copy, article pages, category archives, and a collapsing mobile menu.

## Run locally

1. Install Ruby 3.1 or newer.
2. In this folder, run `bundle install`.
3. Run `bundle exec jekyll serve`.
4. Open `http://localhost:4000`.

## Add a post

Create a Markdown file in `_posts` named `YYYY-MM-DD-your-title.md`:

```yaml
---
layout: post
title: Your post title
date: 2026-09-29
categories: [journal]
card_size: large
image: /assets/images/your-image.jpg
image_alt: A useful description of the image
---

The opening paragraph becomes the card excerpt.

<!--more-->

The rest of the post goes here.
```

Use `journal`, `essays`, or `research` as the first category. Card sizes are `small`, `medium`, `large`, or `wide`.

## Personalise

- Edit `_config.yml` for title, description, author, URL, and navigation.
- Replace the sample biography in `about.md`.
- Delete or replace the sample files in `_posts` and `assets/images`.
- Set `url` to your full domain and `baseurl` to the repository path when publishing below a subpath.

## Publish with GitHub Pages

Push the folder to a repository, choose **GitHub Actions** as the Pages source, and use GitHub's official Jekyll workflow. The theme uses only core Jekyll features, so it works with the standard Jekyll build.
