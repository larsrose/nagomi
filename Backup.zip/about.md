---
layout: page
title: About
permalink: /about/
---

Nagomi is... 
