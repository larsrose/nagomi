---
layout: category
title: Journal
category: journal
permalink: /journal/
description: Short-form observations, daily notes, and small thoughts that don't need a thesis.
---
